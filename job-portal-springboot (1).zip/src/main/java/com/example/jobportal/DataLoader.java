package com.example.jobportal;

import com.example.jobportal.model.Role;
import com.example.jobportal.model.User;
import com.example.jobportal.repository.RoleRepository;
import com.example.jobportal.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Set;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner init(UserRepository users, RoleRepository roles, BCryptPasswordEncoder encoder) {
        return args -> {
            Role empRole = roles.findByName("EMPLOYER").orElseGet(() -> roles.save(new Role("EMPLOYER")));
            Role appRole = roles.findByName("APPLICANT").orElseGet(() -> roles.save(new Role("APPLICANT")));

            if (users.findByUsername("employer").isEmpty()) {
                User u = new User();
                u.setUsername("employer");
                u.setEmail("employer@example.com");
                u.setPassword(encoder.encode("password"));
                u.setRoles(Set.of(empRole));
                users.save(u);
            }
            if (users.findByUsername("applicant").isEmpty()) {
                User u = new User();
                u.setUsername("applicant");
                u.setEmail("applicant@example.com");
                u.setPassword(encoder.encode("password"));
                u.setRoles(Set.of(appRole));
                users.save(u);
            }
        };
    }
}
