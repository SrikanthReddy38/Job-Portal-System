package com.example.jobportal.service;

import com.example.jobportal.model.*;
import com.example.jobportal.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationService {

    @Autowired private ApplicationRepository applicationRepository;

    public Application apply(User applicant, Job job) {
        Application a = new Application();
        a.setApplicant(applicant);
        a.setJob(job);
        a.setStatus("SUBMITTED");
        return applicationRepository.save(a);
    }

    public List<Application> forApplicant(User applicant) {
        return applicationRepository.findByApplicant(applicant);
    }

    public List<Application> forJob(Job job) { return applicationRepository.findByJob(job); }
}
