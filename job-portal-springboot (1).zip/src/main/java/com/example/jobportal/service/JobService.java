package com.example.jobportal.service;

import com.example.jobportal.model.Job;
import com.example.jobportal.model.User;
import com.example.jobportal.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobService {

    @Autowired private JobRepository jobRepository;

    public Job save(Job job) { return jobRepository.save(job); }

    public List<Job> search(String q) {
        if (q == null || q.isBlank()) return jobRepository.findAll();
        return jobRepository.findByTitleContainingIgnoreCaseOrLocationContainingIgnoreCaseOrCompanyContainingIgnoreCase(q, q, q);
    }

    public List<Job> byEmployer(User employer) { return jobRepository.findByEmployer(employer); }

    public Job findById(Long id) { return jobRepository.findById(id).orElseThrow(); }
}
