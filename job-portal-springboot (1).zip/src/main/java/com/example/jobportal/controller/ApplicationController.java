package com.example.jobportal.controller;

import com.example.jobportal.model.Job;
import com.example.jobportal.model.User;
import com.example.jobportal.service.ApplicationService;
import com.example.jobportal.service.JobService;
import com.example.jobportal.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ApplicationController {

    @Autowired private ApplicationService applicationService;
    @Autowired private JobService jobService;
    @Autowired private UserService userService;

    @PostMapping("/applicant/apply/{jobId}")
    public String apply(@PathVariable Long jobId, Authentication auth) {
        User applicant = userService.findByUsername(auth.getName()).orElseThrow();
        Job job = jobService.findById(jobId);
        applicationService.apply(applicant, job);
        return "redirect:/applications";
    }

    @GetMapping("/applications")
    public String myApplications(Authentication auth, Model model) {
        User user = userService.findByUsername(auth.getName()).orElseThrow();
        model.addAttribute("applications", applicationService.forApplicant(user));
        return "applications";
    }

    @GetMapping("/employer/jobs/{jobId}/applications")
    public String jobApplications(@PathVariable Long jobId, Authentication auth, Model model) {
        Job job = jobService.findById(jobId);
        model.addAttribute("applications", applicationService.forJob(job));
        model.addAttribute("job", job);
        return "job-applications";
    }
}
