package com.example.jobportal.controller;

import com.example.jobportal.model.Job;
import com.example.jobportal.model.User;
import com.example.jobportal.service.JobService;
import com.example.jobportal.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class JobController {

    @Autowired private JobService jobService;
    @Autowired private UserService userService;

    @GetMapping("/employer/jobs")
    public String employerJobs(Authentication auth, Model model) {
        User emp = userService.findByUsername(auth.getName()).orElseThrow();
        List<Job> jobs = jobService.byEmployer(emp);
        model.addAttribute("jobs", jobs);
        return "employer-jobs";
    }

    @GetMapping("/employer/jobs/new")
    public String newJobForm(Model model) {
        model.addAttribute("job", new Job());
        return "post-job";
    }

    @PostMapping("/employer/jobs")
    public String createJob(@ModelAttribute Job job, Authentication auth) {
        User emp = userService.findByUsername(auth.getName()).orElseThrow();
        job.setEmployer(emp);
        jobService.save(job);
        return "redirect:/employer/jobs";
    }
}
