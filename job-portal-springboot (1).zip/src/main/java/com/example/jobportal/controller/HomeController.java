package com.example.jobportal.controller;

import com.example.jobportal.model.Job;
import com.example.jobportal.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class HomeController {

    @Autowired private JobService jobService;

    @GetMapping("/")
    public String index(@RequestParam(value = "q", required = false) String q, Model model) {
        List<Job> jobs = jobService.search(q);
        model.addAttribute("jobs", jobs);
        model.addAttribute("q", q == null ? "" : q);
        return "index";
    }

    @GetMapping("/login")
    public String login() { return "login"; }
}
