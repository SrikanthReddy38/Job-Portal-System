package com.example.jobportal.repository;

import com.example.jobportal.model.Job;
import com.example.jobportal.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface JobRepository extends JpaRepository<Job, Long> {
    List<Job> findByEmployer(User employer);
    List<Job> findByTitleContainingIgnoreCaseOrLocationContainingIgnoreCaseOrCompanyContainingIgnoreCase(String t, String l, String c);
}
